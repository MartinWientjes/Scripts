brew install dmd
brew install pkg-config
brew install dub
brew install sbt
brew install scalaenv
