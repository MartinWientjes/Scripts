cd ~/Downloads/
curl -O https://rsync.samba.org/ftp/rsync/src/rsync-3.0.9.tar.gz
tar -xzvf rsync-3.0.9.tar.gz
cd rsync-3.0.9