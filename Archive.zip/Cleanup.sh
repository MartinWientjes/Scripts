sudo echo "Cleanup started"
cd ~
echo ">>>> Finding Thumbs.db ....."
sudo find . -name "Thumbs.db" -type f -exec rm {} \;
echo ">>>> Finding .DS_Store ....."
sudo find . -name ".DS_Store" -depth  -type f -exec rm {} \;
echo ">>>> Finding .BridgeCacheT ....."
sudo find . -name ".BridgeCacheT" -depth  -type f -exec rm {} \;
echo "Part 1 finished"

