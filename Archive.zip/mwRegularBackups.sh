# Regular backups
sudo rsync -aE -v --recursive --progress --times --stats /Users/martin/mw/CV/ /Users/martin/Dropbox/CV/
sudo rsync -aE -v --recursive --progress --times --stats /Users/martin/mw/Sollicitaties/ /Users/martin/Dropbox/Sollicitaties/
sudo rsync -aE -v --recursive --progress --times --stats /Users/martin/Documents/Van\ Ede\ Outplacement/ /Users/martin/Dropbox/Van\ Ede\ Outplacement/