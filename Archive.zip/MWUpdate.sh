sudo softwareupdate -i -a
brew update
brew upgrade --all
brew cleanup
npm install npm -g
npm update -g
sudo gem update --system
sudo gem update


sudo conda update -y --all --no-update-deps
sudo pip freeze --local | grep -v '^\-e' | cut -d = -f 1 | xargs -n1 pip install -U
