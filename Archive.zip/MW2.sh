conda update -y --all --no-update-deps
