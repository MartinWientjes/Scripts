# -> df
# Filesystem                                             512-blocks        Used  Available Capacity    iused      ifree %iused  Mounted on
# /dev/disk0s2                                           3905349952  3671229848  233608104    95%    5819261 4289148018    0%   /
# devfs                                                         659         659          0   100%       1142          0  100%   /dev
# map -hosts                                                      0           0          0   100%          0          0  100%   /net
# map auto_home                                                   0           0          0   100%          0          0  100%   /home
# map -fstab                                                      0           0          0   100%          0          0  100%   /Network/Servers
# //Martin@N5550._afpovertcp._tcp.local./R5_TimeMachine 15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_TimeMachine
# /dev/disk1s2                                          15493382992 13524970400 1968412592    88%   14774221 4280193058    0%   /Volumes/Time Machine Backups
# //martin@n5550/R5_TimeMachine                         15494087584 13525609456 1968478128    88% 1690701180  246059766   87%   /Volumes/R5_TimeMachine-1
# //Martin@n5550/Big_Backup                              7800735856    11262704 7789473152     1%    1407836  973684144    0%   /Volumes/Big_Backup
# //Martin@n5550/R5_Adobe_LR                             7800735856    11262704 7789473152     1%    1407836  973684144    0%   /Volumes/R5_Adobe_LR
# //Martin@n5550/R5_Backup_iMac                         15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_Backup_iMac
# //Martin@n5550/R5_Backup_MBP                          15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_Backup_MBP
# //Martin@n5550/R5_Foto_Archief                        15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_Foto_Archief
# //Martin@n5550/iTunes_music                           15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/iTunes_music
# //Martin@n5550/NAS_Public                             15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/NAS_Public
# //Martin@n5550/R5_PC_Beneden                          15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_PC_Beneden
# //Martin@n5550/R5_TimeMachine                         15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_TimeMachine-2
# //Martin@n5550/R5_Video                               15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/R5_Video
# //Martin@n5550/Video                                   7800735856    11262704 7789473152     1%    1407836  973684144    0%   /Volumes/Video
# //Martin@n5550/USBCopy                                15494054816 13525576688 1968478128    88% 1690697084  246059766   87%   /Volumes/USBCopy



#  fstatfs(2), getfsstat(2), statfs(2), getmntinfo(3), compat(5), fstab(5), mount(8), quot(8)q

# >>> lsvfs
# Filesystem                        Refs Flags
# -------------------------------- ----- ---------------
# nfs                                  0
# hfs                                  2 local, dovolfs
# devfs                                1
# autofs                               3
# afpfs                                1
# smbfs                                7


# mount -t smbfs //user@server/sharename share

umount /Volumes/R5_Foto_Archief
umount /Volumes/R5_Backup_iMac
umount /Volumes/R5_TimeMachine-1
umount /Volumes/NAS_Public
umount /Volumes/iTunes_music
umount /Volumes/R5_Backup_MBP
umount /Volumes/R5_Video

mount -t smbfs //martin@n5550/R5_Foto_Archief               /Volumes/R5_Foto_Archief/
mount -t smbfs //martin@n5550/R5_Backup_iMac                /Volumes/R5_Backup_iMac
mount -t smbfs //martin@n5550/R5_TimeMachine                /Volumes/R5_TimeMachine-1
mount -t smbfs //martin@n5550/NAS_Public                    /Volumes/NAS_Public
mount -t smbfs //martin@n5550/iTunes_music                  /Volumes/iTunes_music
mount -t smbfs //martin@n5550/R5_Backup_MBP                 /Volumes/R5_Backup_MBP
mount -t smbfs //martin@n5550/R5_Video                      /Volumes/R5_Video
mount -t smbfs //martin@n5550/R5_Adobe_Lr                   /Volumes/R5_Adobe_Lr

